﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.BaseClass;
using oop.Model;
using System.Net.Http.Headers;
using System.Printing;

namespace ViragSzamolasProject.ViewModel
{
    public class ViragSzamolasViewModel :ViewModelBase
    {
        private ViragSzamolas _viragszamolas;
        public ViragSzamolasViewModel()
        {
            _viragszamolas = new ViragSzamolas();
            SzamolasGomb = new RelayCommand(execute => Szamolas());
        }

        public RelayCommand SzamolasGomb { get; private set; }
        
        public string Tulipan
        {
            get
            {
                return _viragszamolas.Tulipan.ToString();
            }
            set
            {
                try
                {
                    int tul = Convert.ToInt32(value);
                    _viragszamolas.Tulipan = tul;
                }
                catch (Exception e)
                {

                }
            }
        }
        public string Rozsa
        {
            get
            {
                return _viragszamolas.Rozsa.ToString();
            }
            set
            {
                try
                {
                    int rozs = Convert.ToInt32(value);
                    _viragszamolas.Rozsa= rozs;
                }
                catch (Exception e)
                {

                }
            }
        }
        public string Narcisz
        {
            get
            {
                return _viragszamolas.Narcisz.ToString();
            }
            set
            {
                try
                {
                    int nar = Convert.ToInt32(value);
                    _viragszamolas.Narcisz = nar;
                }
                catch (Exception e)
                {

                }
            }
        }

        public string Osszeg
        {
            get
            {
                return "Virágok összege: " + _viragszamolas.Osszeg + " Ft";
            }
        }
        private void Szamolas()
        {
            OnPropertyChanged(nameof(Osszeg));
        }
    } 
}