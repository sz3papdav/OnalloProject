﻿using System;
using System.Collections.Generic;
using System.Text;

namespace oop.Model
{
    class ViragSzamolas
    {
        private int _tulipan;
        private int _rozsa;
        private int _narcisz;

        public int Tulipan
        {
            get => _tulipan;
            set => _tulipan = value;
        }
        public int Rozsa
        {
            get => _rozsa;
            set => _rozsa = value;
        }
        public int Narcisz
        {
            get => _narcisz;
            set => _narcisz = value;
        }
        public int TulipanAra
        {
            get
            {
                return 300;
            }

        }
        public int RozsaAra
        {
            get
            {
                return 500;
            }
        }
        public int NarciszAra
        {
            get
            {
                return 400;
            }
        }
        public double Osszeg
        {
            get { return (TulipanAra*Tulipan) + (RozsaAra*Rozsa) + (NarciszAra*Narcisz); }
        }
    }
}